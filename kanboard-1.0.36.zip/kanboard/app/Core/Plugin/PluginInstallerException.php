<?php

namespace Kanboard\Core\Plugin;

use Exception;

/**
 * Class PluginInstallerException
 *
 * @package Kanboard\Core\Plugin
 * @author  Frederic Guillot
 */
class PluginInstallerException extends Exception
{
}
