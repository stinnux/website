<?php

namespace Kanboard\Core\ExternalTask;

/**
 * Class AccessForbiddenException
 *
 * @package Kanboard\Core\ExternalTask
 * @author  Frederic Guillot
 */
class AccessForbiddenException extends ExternalTaskException
{
}
